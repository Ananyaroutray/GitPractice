package com.java.college;

public class Dummy {

	public static void main(String[] args) {
		System.out.println(new CollegeImpl().showCollegeDAO());
	}
}
